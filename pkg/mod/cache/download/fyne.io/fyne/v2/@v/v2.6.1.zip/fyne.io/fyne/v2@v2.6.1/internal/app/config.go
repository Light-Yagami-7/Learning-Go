package app

func RootConfigDir() string {
	return rootConfigDir()
}
